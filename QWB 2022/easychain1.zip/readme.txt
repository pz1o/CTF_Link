note:
The kernel is pulled from github, you can compile it yourself with the config file: https://github.com/torvalds/linux 